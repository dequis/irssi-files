#include "common.h"
#include "term.h"

#define MODULE_NAME "fe-text"

extern int quitting;
void irssi_redraw(void);
void irssi_set_dirty(void);
